pluginManagement {
    repositories {
        gradlePluginPortal()
    }
}

plugins {
    id("de.fayard.refreshVersions") version "0.40.1"
}

rootProject.name = "sync"

refreshVersions {
    enableBuildSrcLibs()
}
