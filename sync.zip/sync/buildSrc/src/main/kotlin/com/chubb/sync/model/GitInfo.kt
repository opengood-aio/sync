package com.chubb.sync.model

data class GitInfo(
    val remote: String = "origin",
    val branch: String = "dev"
) {
    companion object {
        val EMPTY = GitInfo(
            remote = "",
            branch = ""
        )
    }
}
