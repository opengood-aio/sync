package com.chubb.sync.model

import java.io.File

data class SyncContext(
    val workspaceDir: File
)
