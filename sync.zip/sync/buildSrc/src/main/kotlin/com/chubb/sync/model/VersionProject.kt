package com.chubb.sync.model

import com.chubb.sync.enumeration.VersionType

data class VersionProject(
    val id: String,
    val type: VersionType,
    val inclusions: List<String>
)
