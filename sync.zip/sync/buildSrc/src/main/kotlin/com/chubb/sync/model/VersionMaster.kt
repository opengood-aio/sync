package com.chubb.sync.model

import com.chubb.sync.enumeration.BuildToolType
import com.chubb.sync.enumeration.VersionType
import com.chubb.sync.enumeration.VersionFileType

data class VersionMaster(
    val name: String,
    val id: String,
    val tools: List<BuildToolType>,
    val type: VersionType,
    val uri: String,
    val key: String,
    val subKey: String = "",
    val files: List<VersionFileType>,
    val pattern: String,
    val inclusions: List<String> = emptyList()
)
