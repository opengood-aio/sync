package com.chubb.sync.model

import com.chubb.sync.enumeration.BuildGradleType
import com.chubb.sync.enumeration.BuildToolType
import com.chubb.sync.enumeration.LanguageType
import com.chubb.sync.enumeration.MavenFileType
import com.chubb.sync.enumeration.SettingsGradleType

data class BuildInfo(
    val language: LanguageType,
    val buildTool: BuildToolType,
    val buildGradle: BuildGradleType,
    val settingsGradle: SettingsGradleType,
    val mavenFile: MavenFileType
) {
    companion object {
        val EMPTY = BuildInfo(
            language = LanguageType.UNKNOWN,
            buildTool = BuildToolType.UNKNOWN,
            buildGradle = BuildGradleType.NONE,
            settingsGradle = SettingsGradleType.NONE,
            mavenFile = MavenFileType.NONE
        )
    }
}
