package com.chubb.sync.model

import java.io.File

data class SyncMaster(
    val version: String,
    val config: ConfigInfo = ConfigInfo(),
    val versioning: List<VersionMaster>
) {
    lateinit var dir: File
    lateinit var file: File

    companion object {
        val EMPTY = SyncMaster(
            version = "",
            versioning = emptyList()
        )
    }
}
